package com.rays.dao;

import com.rays.common.BaseDAOInt;
import com.rays.dto.SubjectDTO;
/**
 * Sushobhit Pandey 
 *
 */
public interface SubjectDAOInt extends BaseDAOInt<SubjectDTO>{

}
