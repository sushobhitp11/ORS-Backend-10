package com.rays.dao;

import com.rays.common.BaseDAOInt;
import com.rays.dto.CustomerDTO;

public interface CustomerDAOInt extends BaseDAOInt<CustomerDTO> {

}
