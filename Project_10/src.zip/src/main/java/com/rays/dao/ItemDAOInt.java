package com.rays.dao;

import com.rays.common.BaseDAOInt;
import com.rays.dto.ItemDTO;

public interface ItemDAOInt extends BaseDAOInt<ItemDTO>{
	

}
