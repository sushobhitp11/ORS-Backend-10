package com.rays.dao;

import com.rays.common.BaseDAOInt;
import com.rays.dto.TimeTableDTO;
/**
 * Sushobhit Pandey 
 *
 */
public interface TimeTableDAOInt extends BaseDAOInt<TimeTableDTO> {

	
}
