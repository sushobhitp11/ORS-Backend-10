package com.rays.dao;

import com.rays.common.BaseDAOInt;
import com.rays.dto.CartDTO;

public interface CartDAOInt extends BaseDAOInt<CartDTO> {

}
