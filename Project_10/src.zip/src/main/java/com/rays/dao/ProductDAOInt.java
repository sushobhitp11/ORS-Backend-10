package com.rays.dao;

import com.rays.common.BaseDAOInt;
import com.rays.dto.ProductDTO;

public interface ProductDAOInt extends BaseDAOInt<ProductDTO> {

}
