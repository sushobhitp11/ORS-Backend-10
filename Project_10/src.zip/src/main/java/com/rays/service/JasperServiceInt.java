package com.rays.service;

public interface JasperServiceInt {

}
