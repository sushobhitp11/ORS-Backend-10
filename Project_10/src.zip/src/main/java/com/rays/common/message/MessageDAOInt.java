package com.rays.common.message;

import com.rays.common.BaseDAOInt;

/**
 * Role DAO interface.
 * Sushobhit Pandey 
 */
public interface MessageDAOInt extends BaseDAOInt<MessageDTO> {

}
